import Certificate from "./Certificate";
import './index.css';

function App() {
  return (
    <div className="App">
     <Certificate/>
    </div>
  );
}

export default App;
